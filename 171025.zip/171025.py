
# Part 1:
def count_strings(n):
    return 3 ** n
n = 1000
result = count_strings(n) % 9999
print(result)  # a_1000 mod 9999
# Part 2:
def count_palindromes(n):
    return 3 ** ((n + 1) // 2)
n = 1000
result = count_palindromes(n) % 9999
print(result)  # b_1000 mod 9999

# Part 3:
import math
def count_S_ijk(i, j, k):
    total = i + j + k
    return math.factorial(total) // (math.factorial(i) * math.factorial(j) * math.factorial(k))
i, j, k = 100, 80, 90
result = count_S_ijk(i, j, k) % 9999
print(result)
# Part 4:
def count_no_consecutive_a(n):
    if n == 0:
        return 1
    elif n == 1:
        return 3
    d_prev2, d_prev1 = 1, 3
    for i in range(2, n+1):
        d = 2 * d_prev1 + 2 * d_prev2
        d_prev2, d_prev1 = d_prev1, d
    return d_prev1
n = 1000
result = count_no_consecutive_a(n) % 9999
print(result)
# Part 5: a dau tien truoc b truoc c
from itertools import product
def count_En(n):
    A = ['a', 'b', 'c']
    count = 0
    for s in product(A, repeat=n):
        first_a = None
        first_b = None
        first_c = None
        for idx, ch in enumerate(s):
            if ch == 'a' and first_a is None:
                first_a = idx
            if ch == 'b' and first_b is None:
                first_b = idx
            if ch == 'c' and first_c is None:
                first_c = idx
        if (first_a is None or first_b is None or first_c is None or 
            (first_a < first_b < first_c)):
            count += 1
    return count
n = 4
result = count_En(n)  # Nên in số đếm cho n nhỏ
print(result)
#giai 6,7 
def recurrence(N, mod):
    a0, b0 = 1, 0  # (3 - sqrt(7))^0 = 1
    a1, b1 = 3, -1 # (3 - sqrt(7))^1 = 3 - sqrt(7)
    a = [a0, a1]
    b = [b0, b1]
    for n in range(2, N+1):
        new_a = 3*a[-1] - 7*b[-1]
        new_b = 3*b[-1] - a[-1]
        a.append(new_a % mod)
        b.append(new_b % mod)
    return (a[N] + b[N]) % mod

# To compute (a_1000 + b_1000) % 999:
print(recurrence(1000, 999))



