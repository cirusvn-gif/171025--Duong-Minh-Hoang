
# Part 1:
def count_strings(n):
    return 3 ** n
n = 1000
result = count_strings(n) % 9999
print(result)  # a_1000 mod 9999
# Part 2:
def count_palindromes(n):
    return 3 ** ((n + 1) // 2)
n = 1000
result = count_palindromes(n) % 9999
print(result)  # b_1000 mod 9999

# Part 3:
import math
def count_S_ijk(i, j, k):
    total = i + j + k
    return math.factorial(total) // (math.factorial(i) * math.factorial(j) * math.factorial(k))
i, j, k = 100, 80, 90
result = count_S_ijk(i, j, k) % 9999
print(result)
# Part 4:
def count_no_consecutive_a(n):
    if n == 0:
        return 1
    elif n == 1:
        return 3
    d_prev2, d_prev1 = 1, 3
    for i in range(2, n+1):
        d = 2 * d_prev1 + 2 * d_prev2
        d_prev2, d_prev1 = d_prev1, d
    return d_prev1
n = 1000
result = count_no_consecutive_a(n) % 9999
print(result)
# Part 5: a truoc b truoc c
from itertools import product
def count_En(n):
    A = ['a', 'b', 'c']
    count = 0
    for s in product(A, repeat=n):
        first_a = None
        first_b = None
        first_c = None
        for idx, ch in enumerate(s):
            if ch == 'a' and first_a is None:
                first_a = idx
            if ch == 'b' and first_b is None:
                first_b = idx
            if ch == 'c' and first_c is None:
                first_c = idx
        if (first_a is None or first_b is None or first_c is None or 
            (first_a < first_b < first_c)):
            count += 1
    return count
n = 4
result = count_En(n)  # Nên in số đếm cho n nhỏ
print(result)
# Recur:
# a_{n+1} = 3*a_n - 7*b_n
# b_{n+1} = 3*b_n - a_n
# Initial values: a_0 = 1, b_0 = 0

def compute_ab(n):
    a, b = 1, 0  # a_0, b_0
    for _ in range(n):
        new_a = 3 * a - 7 * b
        new_b = 3 * b - a
        a, b = new_a, new_b
    return a, b

# Example: tim a_1000 va b_1000, sau do compute (a_1000 + b_1000) % 999
n = 1000
a_n, b_n = compute_ab(n)
mod_result = (a_n + b_n) % 999
print("a_1000:", a_n)
print("b_1000:", b_n)
print("(a_1000 + b_1000) mod 999:", mod_result)

